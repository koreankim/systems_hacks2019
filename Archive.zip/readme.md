# Systems Hacks 2019
## Tools
### Libraries
1. Jquery
2. [Geo-bootstrap](https://github.com/divshot/geo-bootstrap)

### Software
1. Visual Studio Code
2. Gitbash (Windows 10)
3. Source Tree

### Browser
1. Firefox